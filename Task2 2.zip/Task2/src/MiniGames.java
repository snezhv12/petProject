import java.util.*;

public class MiniGames {
    public static int numberGuessingGame() {
        Random random = new Random();
        Scanner sc = new Scanner(System.in);
        int targetNumber = random.nextInt(100) + 1;
        int attempts = 7;
        int reward = 0;

        System.out.println("Guess the number between 1 and 100:");

        for (int i = 1; i <= attempts; i++) {
            System.out.print("Attempt " + i + ": ");
            int guess = sc.nextInt();

            if (guess == targetNumber) {
                reward = 8 - i; // Reward based on attempt
                System.out.println("Correct! You earned " + reward + " food.");
                return reward;
            } else if (guess < targetNumber) {
                System.out.println("Too low!");
            } else {
                System.out.println("Too high!");
            }
        }

        System.out.println("No attempts left. No food earned.");
        return 0;
    }

    public static int wordScrambleGame() {
        Random random = new Random();
        Scanner sc = new Scanner(System.in);

        // List of pet-related words
        String[] words = {"bone", "smile", "owner", "happy", "energy", "play", "rest"};

        // Select and scramble a random word
        String word = words[random.nextInt(words.length)];
        String scrambled = scrambleWord(word);
        int reward = 0;

        System.out.println("Unscramble the word: " + scrambled);

        for (int i = 1; i <= 3; i++) {
            System.out.print("Attempt " + i + ": ");
            String guess = sc.next();

            if (guess.equalsIgnoreCase(word)) {
                // Reward based on the attempt number
                reward = 4 - i;
                System.out.println("Terrific! You earned " + reward + " food.");
                return reward;
            } else {
                System.out.println("No luck!");
            }
        }

        System.out.println("Ooops, you're out of attempts. No food earned.");
        return 0;
    }

    // Helper method to scramble a word
    private static String scrambleWord(String word) {
        List<Character> letters = new ArrayList<>();
        for (char c : word.toCharArray()) {
            letters.add(c);
        }
        Collections.shuffle(letters);
        StringBuilder scrambled = new StringBuilder();
        for (char c : letters) {
            scrambled.append(c);
        }
        return scrambled.toString();
    }

    public static int multiplicationGame() {
        Random random = new Random();
        Scanner sc = new Scanner(System.in);

        // Generate two random numbers
        int num1 = random.nextInt(100) + 1;
        int num2 = random.nextInt(100) + 1;

        // Calculate the correct answer
        int correctAnswer = num1 * num2;

        System.out.println("What is " + num1 + " * " + num2 + "? You have 15 seconds to answer!");

        // Record start time
        long startTime = System.currentTimeMillis();

        // Player's answer
        int playerAnswer = sc.nextInt();

        // Record end time
        long endTime = System.currentTimeMillis();

        // Calculate elapsed time in seconds
        double timeTaken = (endTime - startTime) / 1000.0;

        // Check if the answer is correct
        if (timeTaken <= 15) {
            if (playerAnswer == correctAnswer) {
                System.out.printf("Correct! You earned 5 food. Time taken: %.2f seconds.%n", timeTaken);
                return 5;
            } else {
                System.out.printf("Wrong answer! You earned 0 food. Time taken: %.2f seconds.%n", timeTaken);
                return 0;
            }
        } else {
            if (playerAnswer == correctAnswer) {
                System.out.printf("Correct! But too slow:( Time taken: %.2f seconds. No food earned.%n", timeTaken);
            } else {
                System.out.printf("Incorrect and out of time! Time taken: %.2f seconds. No food earned.%n", timeTaken);
            }
            return 0;
        }
    }
    public static int fortuneWheelGame() {
        Random random = new Random();
        int randomNumber = random.nextInt(100) + 1; // Generate random number between 1 and 100
        int reward = 0;

        System.out.println("The number is: " + randomNumber);

        if (isPrime(randomNumber)) {
            reward = 10; // Prime number reward
            System.out.println("Congratulations! It's a prime number. You earned 10 food.");
        } else if (randomNumber % 3 == 0 && randomNumber % 5 == 0) {
            reward = 3; // Divisible by 3 and 5
            System.out.println("Great! The number is divisible by 3 and 5. You earned 3 food.");
        } else if (randomNumber % 2 == 0 && randomNumber % 4 == 0) {
            reward = 2; // Divisible by 2 and 4
            System.out.println("Nice! The number is divisible by 2 and 4. You earned 2 food.");
        } else {
            System.out.println("Sorry! No reward this time.");
        }

        return reward;
    }

    // Helper method to check if a number is prime
    private static boolean isPrime(int number) {
        if (number <= 1) {
            return false; // Numbers <= 1 are not prime
        }
        for (int i = 2; i <= Math.sqrt(number); i++) {
            if (number % i == 0) {
                return false; // Divisible by another number, not prime
            }
        }
        return true; // Prime number
    }

}
