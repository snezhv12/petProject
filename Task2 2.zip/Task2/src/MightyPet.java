public class MightyPet extends Pet {
    private int strength; // Unique to MightyPet

    // Constructor
    public MightyPet(String name, int happiness, int hunger, int energy, int strength) {
        super(name, happiness, hunger, energy); // Call parent class constructor
        this.strength = constrain(strength);    // Ensure strength is within valid range
    }

    // Overridden methods to provide MightyPet-specific behavior
    @Override
    public String updateStatus() {
        // Custom behavior for MightyPet
        changeHappiness(-2);
        changeHunger(+1);
        changeEnergy(-1);

        // Return updated status as a string (matching parent method)
        return super.getName() + " - Happiness: " + getHappiness() +
                ", Hunger: " + getHunger() +
                ", Energy: " + getEnergy();
    }

    @Override
    public void feed() {
        setHappiness(getHappiness() + 15);
        setHunger(getHunger() - 25);
    }

    @Override
    public void play() {
        setHappiness(getHappiness() + 20);
        setHunger(getHunger() + 10);
        setEnergy(getEnergy() - 10);
    }

    @Override
    public void rest() {
        setHunger(getHunger() + 2);
        setEnergy(getEnergy() + 30);
    }

    // Overriding getStatus to include MightyPet-specific details
    @Override
    public String getStatus() {
        return String.format("Pet [Type=Mighty, ID=%d, Name=%s, Happiness=%d, Hunger=%d, Energy=%d, Strength=%d]",
                super.getId(), super.getName(), super.getHappiness(), super.getHunger(), super.getEnergy(), this.strength);
    }


    // Getter and Setter for strength
    public int getStrength() {
        return strength;
    }

    public void setStrength(int strength) {
        this.strength = constrain(strength);
    }
}








