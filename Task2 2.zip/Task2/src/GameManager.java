import java.util.Scanner;
import java.util.Comparator;

public class GameManager {
    private final Player player;
    private int turn;


    public GameManager(String playerName) {
        player = new Player(playerName);
        turn = 0;
    }

    public void startGame() {
        Scanner sc = new Scanner(System.in);
        boolean gameOver = false;

        while (!gameOver) {
            turn++;
            System.out.println("\n--- Turn " + turn + " ---");
            System.out.println("1. Create a new pet");
            System.out.println("2. Feed a pet");
            System.out.println("3. Play with a pet");
            System.out.println("4. Let a pet rest");
            System.out.println("5. Play a mini-game");
            System.out.println("6. Display status");
            System.out.println("7. Exit game");
            System.out.println("8. Sort pets by name and happiness");
            System.out.println("9. Search for a pet by name");
            System.out.println("10. Display pet counts");
            System.out.print("Choose an option: ");
            int choice = sc.nextInt();

            switch (choice) {
                case 1 -> createPet();
                case 2 -> feedPet();
                case 3 -> playWithPet();
                case 4 -> letPetRest();
                case 5 -> {
                    playMiniGame();
                    continue; // skip turns for mini-games
                }
                case 6 -> System.out.println(player.getStatus());
                case 7 -> gameOver = true;
                case 8 -> sortPets(); // Call the method to sort pets
                case 9 -> searchPet(); // Call the method to search for a pet
                case 10 -> displayPetCounts(); // Call the method to display pet counts
                default -> System.out.println("Invalid choice! Please try again.");
            }


            updatePetsStatus();
            gameOver = checkGameOver();
        }

        System.out.println("You've lost! Turns survived: " + turn);
    }

    private void createPet() {
        Scanner sc = new Scanner(System.in);

        // Ask the user for the type of pet
        System.out.println("Do you want to create a 'normal' pet or a 'mighty' pet? (Enter 'normal' or 'mighty')");
        String petType = sc.nextLine().trim().toLowerCase(); // Normalize input

        // Ask for the pet's name
        System.out.print("Enter the pet's name: ");
        String name = sc.nextLine();

        // Validate and create the pet based on the type
        if (petType.equals("normal")) {
            if (name.isEmpty()) {
                player.addPet(new Pet(50, 80, 50)); // Create a pet with default values
            } else {
                player.addPet(new Pet(name, 50, 80, 50)); // Create a named normal pet
            }
            System.out.println("Normal pet created!");
        } else if (petType.equals("mighty")) {
            if (name.isEmpty()) {
                player.addPet(new MightyPet("MightyPet", 50, 80, 50, 20)); // Mighty pet with default values
            } else {
                player.addPet(new MightyPet(name, 50, 80, 50, 20)); // Create a named mighty pet
            }
            System.out.println("Mighty pet created!");
        } else {
            System.out.println("Invalid choice. Please try again.");
        }
    }
    private void sortPets() {
        if (player.getPets().isEmpty()) {
            System.out.println("No pets to sort.");
            return;
        }

        player.getPets().sort(
                Comparator.comparing((Pet p) -> p.getName() != null ? p.getName() : "")
                        .thenComparing((Pet p) -> -p.getHappiness())
        );

        System.out.println("Pets sorted by name (ascending) and happiness (descending):");
        for (Pet pet : player.getPets()) {
            System.out.println(pet.getStatus());
        }
    }

    private void searchPet() {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter the name of the pet to search: ");
        String searchName = sc.nextLine();

        boolean found = false;
        for (Pet pet : player.getPets()) {
            if (pet.getName().equalsIgnoreCase(searchName)) {
                System.out.println("Pet found:");
                System.out.println(pet.getStatus());
                found = true;
            }
        }

        if (!found) {
            System.out.println("No pet found with the name \"" + searchName + "\".");
        }
    }
    private void displayPetCounts() {
        int normalCount = 0;
        int mightyCount = 0;

        for (Pet pet : player.getPets()) {
            if (pet instanceof MightyPet) {
                mightyCount++;
            } else {
                normalCount++;
            }
        }

        System.out.println("Total number of pets: " + player.getPets().size());
        System.out.println("Number of normal pets: " + normalCount);
        System.out.println("Number of mighty pets: " + mightyCount);
    }

    private void feedPet() {
        Scanner sc = new Scanner(System.in);
        if (player.getPets().isEmpty()) {
            System.out.println("No pets to feed.");
            return;
        }
        System.out.println("Select a pet to feed:");
        for (int i = 0; i < player.getPets().size(); i++) {
            System.out.println((i + 1) + ". " + player.getPets().get(i).getName());
        }
        int choice = sc.nextInt() - 1;

        if (choice >= 0 && choice < player.getPets().size()) {
            player.feedPet(player.getPets().get(choice));
        } else {
            System.out.println("Invalid choice.");
        }
    }

    private void playWithPet() {
        Scanner sc = new Scanner(System.in);
        if (player.getPets().isEmpty()) {
            System.out.println("No pets to play with.");
            return;
        }

        System.out.println("Select a pet to play with:");
        for (int i = 0; i < player.getPets().size(); i++) {
            System.out.println((i + 1) + ". " + player.getPets().get(i).getName());
        }
        int choice = sc.nextInt() - 1;

        if (choice >= 0 && choice < player.getPets().size()) {
            Pet selectedPet = player.getPets().get(choice);
            selectedPet.play();  // Call the play method to update the pet's values
            System.out.println("You played with " + selectedPet.getName() + ".");
        } else {
            System.out.println("Invalid choice.");
        }
    }

    private void letPetRest() {
        Scanner sc = new Scanner(System.in);
        if (player.getPets().isEmpty()) {
            System.out.println("No pets to let rest.");
            return;
        }

        System.out.println("Select a pet to let rest:");
        for (int i = 0; i < player.getPets().size(); i++) {
            System.out.println((i + 1) + ". " + player.getPets().get(i).getName());
        }
        int choice = sc.nextInt() - 1;

        if (choice >= 0 && choice < player.getPets().size()) {
            Pet selectedPet = player.getPets().get(choice);
            selectedPet.rest();  // Call the rest method to update the pet's values
            System.out.println(selectedPet.getName() + " is resting.");
        } else {
            System.out.println("Invalid choice.");
        }
    }

    private void playMiniGame() {
        Scanner sc = new Scanner(System.in);
        System.out.println("Choose a mini-game:");
        System.out.println("1. Number Guessing Game");
        System.out.println("2. Word Scramble Game");
        System.out.println("3. Multiplication Game");
        System.out.println("4. Fortune Wheel Game");
        int choice = sc.nextInt();

        int foodEarned = 0;
        switch (choice) {
            case 1 -> foodEarned = MiniGames.numberGuessingGame();
            case 2 -> foodEarned = MiniGames.wordScrambleGame();
            case 3 -> foodEarned = MiniGames.multiplicationGame();
            case 4 -> foodEarned = MiniGames.fortuneWheelGame();
            default -> System.out.println("Invalid choice.");
        }

        player.addFood(foodEarned); // Update player's food supply
    }


    private void updatePetsStatus() {
        System.out.println("\nPet status updates:");
        for (Pet pet : player.getPets()) {
            System.out.println(pet.updateStatus());
        }
    }

    private boolean checkGameOver() {
        if (player.getFoodSupply() <= 0) {
            for (Pet pet : player.getPets()) {
                if (pet.getHunger() <= 80) return false;
            }
            return true;
        }
        return false;
    }
}