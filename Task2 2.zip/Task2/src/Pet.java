import java.util.Objects;

public class Pet {
    // attribute to keep track of the next unique ID
    private static int nextId = 1;

    // Constants for the values
    public final static int MAX_VALUE = 100;
    public final static int MIN_VALUE = 0;

    // Instance attributes
    private final int id;
    private String name;
    private int happiness;
    private int hunger;
    private int energy;

    public Pet(String name, int happiness, int hunger, int energy) {
        this.id = getNextId();
        this.name = name;
        this.happiness = constrain(happiness);
        this.hunger = constrain(hunger);
        this.energy = constrain(energy);
    }
    public Pet(int happiness, int hunger, int energy) {
        this.id = getNextId();
        this.happiness = constrain(happiness);
        this.hunger = constrain(hunger);
        this.energy = constrain(energy);
    }

    public static int getNextId() {
        return nextId++;
    }

    protected int constrain(int value) {
        return Math.max(MIN_VALUE, Math.min(MAX_VALUE, value));
    }

    public String getName() {
        return name;
    }

    public void setHappiness(int happiness) {
        this.happiness = constrain(happiness);
        happinessStatus();
        if (this.happiness == MAX_VALUE) {
            System.out.println(name + "'s happiness is at max level.");
        }
    }

    public int getHappiness() {
        return happiness;
    }

    protected void setHunger(int hunger) {
        this.hunger = constrain(hunger);
        hungerStatus();
        if (this.hunger == MIN_VALUE) {
            System.out.println(name + " is completely full.");
        }
    }

    protected int getHunger() {
        return hunger;
    }

    protected void setEnergy(int energy) {
        this.energy = constrain(energy);
        energyStatus();
        if (this.energy == MAX_VALUE) {
            System.out.println(name + "'s energy is at max level.");
        }

    }

    public int getEnergy() {
        return energy;
    }

// methods for printing status
    private void happinessStatus() {
        if (happiness == 100) {
            System.out.println(name + " is very happy.");
        } else if (happiness > 75) {
            System.out.println(name + " is happy.");
        } else if (happiness > 50) {
            System.out.println(name + " is a little happy.");
        } else if (happiness > 25) {
            System.out.println(name + " is a little sad.");
        } else if (happiness > 0) {
            System.out.println(name + " is sad.");
        } else if (happiness == 0) {
            System.out.println(name + " is very sad.");
        }
    }

    private void hungerStatus() {
        if (hunger == 100) {
            System.out.println(name + " is starving.");
        } else if (hunger > 75) {
            System.out.println(name + " is very hungry.");
        } else if (hunger > 50) {
            System.out.println(name + " is hungry.");
        } else if (hunger > 25) {
            System.out.println(name + " is a little hungry.");
        } else if (hunger > 0) {
            System.out.println(name + " is fine.");
        } else if (hunger == 0) {
            System.out.println(name + " is full.");
        }
    }

    private void energyStatus() {
        if (energy == 100) {
            System.out.println(name + " is full of energy.");
        } else if (energy > 75) {
            System.out.println(name + " is very energized.");
        } else if (energy > 50) {
            System.out.println(name + " is energized.");
        } else if (energy > 25) {
            System.out.println(name + " is a little energized.");
        } else if (energy > 0) {
            System.out.println(name + " is a little tired.");
        } else if (energy == 0) {
            System.out.println(name + " is out of energy.");
        }
    }

    public String updateStatus() {
        System.out.println("Updating pet's status...");
        setHappiness(happiness - 3);
        setHunger(hunger + 5);
        setEnergy(energy - 2);

        return name + " - Happiness: " + happiness +
                ", Hunger: " + hunger +
                ", Energy: " +  energy;
    }

    public void feed() {
        System.out.println("Feeding " + name + " increased happiness and reduced hunger.");
        setHappiness(happiness + 10);
        setHunger(hunger - 20);

    }

    public void play() {
        System.out.println("Playing with " + name + " increased happiness, but also made " + name + " tired.");
        setHappiness(happiness + 15);
        setHunger(hunger + 10);
        setEnergy(energy - 15);

    }

    public void rest() {
        System.out.println("Letting " + name + " rest increased energy but also increased hunger.");
        setHunger(hunger + 5);
        setEnergy(energy + 20);

    }

    public String getStatus() {
        return String.format("Pet [Type=Normal, ID=%d, Name=%s, Happiness=%d, Hunger=%d, Energy=%d]",
                id, name, happiness, hunger, energy);
    }
    public int getId() {
        return id;
    }


    public void printCurrentStatus() {
        System.out.println(getStatus());
    }

    protected void changeHappiness(int delta) {
        setHappiness(getHappiness() + delta);
    }

    protected void changeHunger(int delta) {
        setHunger(getHunger() + delta);
    }

    protected void changeEnergy(int delta) {
        setEnergy(getEnergy() + delta);
    }
    }
