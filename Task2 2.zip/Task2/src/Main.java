import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Get the player's name
        System.out.print("Enter your player name: ");
        String playerName = sc.nextLine();

        // Create a Player instance
        Player player = new Player(playerName);

        // GameManager instance, passing in the player object
        GameManager gameManager = new GameManager(playerName);

        // Start the game loop
        gameManager.startGame();

        sc.close();
    }
}
