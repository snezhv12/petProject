import java.util.ArrayList;

public class Player {

    private String name;
    private int foodSupply;
    private ArrayList<Pet> pets;


    public Player(String name) {
        this.name = name;
        this.foodSupply = 50;  // Start with 50 units of food
        this.pets = new ArrayList<>();
    }

    public void addPet(Pet pet) {
        pets.add(pet);
    }

    public void feedPet(Pet pet) {
        if (foodSupply > 0) {
            pet.feed();
            foodSupply--;
            System.out.println("Fed " + pet.getName() + ". Food supply: " + foodSupply);
        } else {
            System.out.println("Not enough food to feed " + pet.getName());
        }
    }

    public String getStatus() {
        StringBuilder status = new StringBuilder("Player: " + name + "\nFood Supply: " + foodSupply + "\nNumber of Pets: " + pets.size() + "\n");
        for (Pet pet : pets) {
            status.append(pet.getStatus()).append("\n");
        }
        return status.toString();
    }

    public int getFoodSupply() {
        return foodSupply;
    }

    public ArrayList<Pet> getPets() {
        return pets;
    }
    public void addFood(int foodEarned) {
        foodSupply += foodEarned; // Increase food supply by the amount earned
        System.out.println("Food supply increased by " + foodEarned + ". Current food supply: " + foodSupply);
    }


}